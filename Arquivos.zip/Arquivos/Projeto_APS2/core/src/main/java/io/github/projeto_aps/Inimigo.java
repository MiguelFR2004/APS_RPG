package io.github.projeto_aps;

import java.util.Random;

import com.badlogic.gdx.graphics.Texture;

import io.github.projeto_aps.Habilidade.HabilidadeID;

public class Inimigo extends Personagem
{
	public static enum TipoDeInimigo
	{
		AR,
		TERRA,
		AGUA,
		FOGO,
		CHEFE;
	}

	// Quantos inimigos vivos estão no array.
	static public int inimigosAtivos = 0;

	// Métodos da classe Inimigo:
	//
	// public Inimigo(TipoDeInimigo tipoPassado)
	// public void JogarRodada(Protagonista protagonista)
	// public void RodadaTipoAr(Protagonista protagonista)
	// public void RodadaTipoTerra(Protagonista protagonista)
	// public void RodadaTipoAgua(Protagonista protagonista)
	// public void RodadaTipoFogo(Protagonista protagonista)
	// public void RodadaTipoChefe(Protagonista protagonista)

	public Inimigo(TipoDeInimigo tipoPassado)
	{
		super();

		alfa = 1;

		switch (tipoPassado)
		{
			case AR: 
				nome = "Poluição do Ar";
				parado1 = new Texture("ar\\AIR-000.png");
				parado2 = new Texture("ar\\AIR-001.png");
				efeito = new Texture("ar\\AIR-002.png");
				atacando = new Texture("ar\\AIR-003.png");
				atacado = new Texture("ar\\AIR-004.png");
				vidaMax = 100;
        		vidaAtual = 100;
				energia = 0;
				energiaPorRodada = 20;
				ataque = 1;
				defesa = 1;
				habilidades = new Habilidade[4];
				habilidades[0] = new Habilidade(0, HabilidadeID.BARULHO_INCESSANTE);
				habilidades[1] = new Habilidade(1, HabilidadeID.GASES_ESTUFA);
				habilidades[2] = new Habilidade(2, HabilidadeID.FUMACA);
				habilidades[3] = new Habilidade(3, HabilidadeID.SMOG);
				break;
			case AGUA: 
				nome = "Poluição da Água";
				parado1 = new Texture("agua\\WATER-000.png");
				parado2 = new Texture("agua\\WATER-001.png");
				efeito = new Texture("agua\\WATER-002.png");
				atacando = new Texture("agua\\WATER-003.png");
				atacado = new Texture("agua\\WATER-004.png");
				vidaMax = 75;
        		vidaAtual = 75;
				energia = 10;
				energiaPorRodada = 10;
				ataque = 2;
				defesa = 3;
				habilidades = new Habilidade[3];
				habilidades[0] = new Habilidade(0, HabilidadeID.CHUVA_ACIDA);
				habilidades[1] = new Habilidade(1, HabilidadeID.EUTROFIZACAO);
				habilidades[2] = new Habilidade(2, HabilidadeID.ALAGAMENTO);
				break;
			case TERRA: 
				nome = "Poluição da Terra";
				parado1 = new Texture("terra\\EARTH-000.png");
				parado2 = new Texture("terra\\EARTH-001.png");
				efeito = new Texture("terra\\EARTH-002.png");
				atacando = new Texture("terra\\EARTH-003.png");
				atacado = new Texture("terra\\EARTH-004.png");
				vidaMax = 125;
        		vidaAtual = 100;
				energia = 0;
				energiaPorRodada = 10;
				ataque = 1;
				defesa = 5;
				habilidades = new Habilidade[4];
				habilidades[0] = new Habilidade(0, HabilidadeID.AGROTOXICO);
				habilidades[1] = new Habilidade(1, HabilidadeID.EROSAO);
				habilidades[2] = new Habilidade(2, HabilidadeID.DESMATAMENTO);
				habilidades[3] = new Habilidade(3, HabilidadeID.DESLIZAMENTO);
				break;
			case FOGO: 
				nome = "Poluição de Fogo";
				parado1 = new Texture("fogo\\FIRE-000.png");
				parado2 = new Texture("fogo\\FIRE-001.png");
				efeito = new Texture("fogo\\FIRE-002.png");
				atacando = new Texture("fogo\\FIRE-003.png");
				atacado = new Texture("fogo\\FIRE-004.png");
				vidaMax = 100;
        		vidaAtual = 100;
				energia = 0;
				energiaPorRodada = 10;
				ataque = 3;
				defesa = 5;
				habilidades = new Habilidade[4];
				habilidades[0] = new Habilidade(0, HabilidadeID.INCENDIO_FLORESTAL);
				habilidades[1] = new Habilidade(1, HabilidadeID.CHUVA_DE_CINZAS);
				habilidades[2] = new Habilidade(2, HabilidadeID.FUMO_TOXICO);
				habilidades[3] = new Habilidade(3, HabilidadeID.QUEIMADA);
				break;
			case CHEFE:
				nome = "Pedro Feito";
				parado1 = new Texture("chefe\\PEDRO-000.png");
				parado2 = new Texture("chefe\\PEDRO-001.png");
				efeito = new Texture("chefe\\PEDRO-002.png");
				atacando = new Texture("chefe\\PEDRO-003.png");
				atacado = new Texture("chefe\\PEDRO-004.png");
				vidaMax = 500;
        		vidaAtual = 500;
				energia = 0;
				energiaPorRodada = 10;
				ataque = 0;
				defesa = 0;
				habilidades = new Habilidade[1];
				habilidades[0] = new Habilidade(0, HabilidadeID.CORRUPCAO);
				break;
		}
		spriteAtual = parado1;


		posX = 580;
		posY = 340;
	}

	// Função para o inimigo decidir qual habilidade usar.
	public void JogarRodada(Protagonista protagonista, JanelaUI janelaUI)
	{
		// O for loop é executado dependendo da quantidade de habilidades do inimigo.
		// Um número aleatório gerado por r determina qual habilidade será usada.
		// Se a aplicação ter successo, o break sai do for e o bool nenhumaHabilidadeUsada se torna falsa,
		// querendo dizer que o inimigo ainda tem energia para usar nessa rodada.
		// Se todas as operações for tiverem fracassado, 
		// o bool nenhumaHabilidadeUsada se mantém verdadeira é a rodada do inimigo acabou.

		Random r = new Random();
		boolean nenhumaHabilidadeUsada = true;	

		for (int i = 0; i < 3; i++)
		{
			int indiceRand = r.nextInt(habilidades.length);

			if (habilidades[indiceRand].Aplicar(this, protagonista, janelaUI))
			{
				nenhumaHabilidadeUsada = false;
				break;
			}
		}

		if (nenhumaHabilidadeUsada)
		{
			possuiRodada = false;
		}
	}
}