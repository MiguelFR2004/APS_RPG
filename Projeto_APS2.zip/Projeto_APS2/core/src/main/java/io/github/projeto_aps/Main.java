package io.github.projeto_aps;

// Classes do libGDX
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.HdpiUtils;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScalingViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends Game {

    private static SpriteBatch batch;
    private static BitmapFont font;
    private static Viewport viewport;
    private static Camera camera;
    private static int scroll = 0;
    private Texture borda;
    
    // Métodos da classe MAIN:
    //
    // public void create()
    // public void dispose()
    // public SpriteBatch getSpriteBatch()
    // public BitmapFont getFont()
    // public Viewport getViewport()
    // public Camera getCamera()

    @Override
    public void create() 
    {
        batch = new SpriteBatch();
        font  = new BitmapFont(Gdx.files.internal("font.fnt"));
        camera = new OrthographicCamera();
        viewport = new FitViewport(900, 600, camera);

        borda = new Texture("grama.png");
        borda.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat);

        // Usa a TelaJogo com a tela ativa.
        this.setScreen(new TelaMenu(this));
    }

    @Override
    public void render() 
    {
        super.render();
    }

    @Override
    public void dispose() 
    {
        batch.dispose();
        font.dispose();
    }

    public SpriteBatch getSpriteBatch()
    {
        return batch;
    }

    public BitmapFont getFont()
    {
        return font;
    }
    
    public Viewport getViewport()
    {
        return viewport;
    }

    public Camera getCamera()
    {
        return camera;
    }

    public void LimparTela()
    {
        batch.setProjectionMatrix(camera.projection);
		batch.setTransformMatrix(camera.view);
        camera.update();

        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
    }

    // Nem olha pra isso, eu copiei colei o código e não faço ideia de como funciona :)
    public void AtualizarBordas()
    {
        if (viewport instanceof ScalingViewport)
        {
            scroll = (scroll + 1) % borda.getHeight();

    	    ScalingViewport scalingViewport = (ScalingViewport)viewport;
	    	int screenWidth = Gdx.graphics.getWidth();
	    	int screenHeight = Gdx.graphics.getHeight();
	    	HdpiUtils.glViewport(0, 0, screenWidth, screenHeight);
	    	batch.getProjectionMatrix().idt().setToOrtho2D(0, 0, screenWidth, screenHeight);
	    	batch.getTransformMatrix().idt();
	    	batch.begin();
	    	float leftGutterWidth = scalingViewport.getLeftGutterWidth();
	    	if (leftGutterWidth > 0) 
            {
	    		batch.draw(borda, 0, 0, (int) -leftGutterWidth, -scroll, (int) leftGutterWidth, screenHeight);
	    		batch.draw(borda, scalingViewport.getRightGutterX(), 0, 0, -scroll, scalingViewport.getRightGutterWidth(), screenHeight);
	    	}
	    	float bottomGutterHeight = scalingViewport.getBottomGutterHeight();
	    	if (bottomGutterHeight > 0) 
            {
	    		batch.draw(borda, 0, 0, scroll, 0, screenWidth, (int) bottomGutterHeight);
	    		batch.draw(borda, 0, scalingViewport.getTopGutterY(), -scroll, (int) -bottomGutterHeight, screenWidth, scalingViewport.getTopGutterHeight());
	    	}
	    	batch.end();
	    	viewport.update(screenWidth, screenHeight, true); // Restore viewport.
        }
    }
}
