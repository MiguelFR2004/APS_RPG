package io.github.projeto_aps;

import com.badlogic.gdx.graphics.Texture;

import io.github.projeto_aps.Habilidade.HabilidadeID;

public class Protagonista extends Personagem
{
    // Métodos da classe Protagonista:
    //
    // public Protagonista(int nivel)
    // public int GetQuantidadeHabilidades()

    public Protagonista(int nivel)
    {
        super();

        vidaMax = 100;
        vidaAtual = 100;
		energia = 0;
		energiaPorRodada = 10;
		ataque = 0;
		defesa = 0;

        posX = 140;
        posY = 340;

        alfa = 1;

        parado1 =  new Texture("protagonista\\SEH-000.png");
		parado2 =  new Texture("protagonista\\SEH-001.png");
        efeito = new Texture("protagonista\\SEH-002.png");
        atacando = new Texture("protagonista\\SEH-003.png");
        atacado = new Texture("protagonista\\SEH-004.png");
		spriteAtual = parado1;

        nome = "Protagonista";

        if (nivel == 5)
        {
            habilidades = new Habilidade[1];

            habilidades[0] = new Habilidade(0, HabilidadeID.TERMINO_DO_MANDATO);
        }
        else
        {
            habilidades = new Habilidade[6];

            habilidades[0] = new Habilidade(0, HabilidadeID.FISCALIZACAO);
            habilidades[1] = new Habilidade(1, HabilidadeID.CONSCIENTIZACAO);
            habilidades[2] = new Habilidade(2, HabilidadeID.LEGISLACAO);
            habilidades[3] = new Habilidade(3, HabilidadeID.PREVENCAO);
            habilidades[4] = new Habilidade(4, HabilidadeID.INVESTIMENTO);
            habilidades[5] = new Habilidade(5, HabilidadeID.MEDIDAS_DIRETAS);
        }
    }
}
