package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public abstract class Personagem
{
    // Classe abstrata para Protagonista e Inimigo, usado principalmente para generalizar uso de habilidades.
    // (Personagem -> Personagem invés de Inimigo -> Protagonista ou Protagonista -> Inimigo)

	// stats...
    protected String nome;
    protected boolean possuiRodada;
	protected boolean morto;
    protected int vidaMax;
    protected int vidaAtual;
	protected int energia;
	protected int energiaPorRodada;
	protected int ataque;
	protected int defesa;

    // Variáveis para o uso de habilidades.
    static protected boolean animacoesEmProgresso;

    // Sprites para animação
	protected Texture parado1;
	protected Texture parado2;
    protected Texture atacando;
	protected Texture atacado;
	protected Texture spriteAtual;
    protected Texture efeitoSprite;
    
    // Essa variável mantém conta da animação sendo tocada atualmente
	protected Animacao animacaoAtual;

    // Variável que mantém conta de quantos segundos para trocar o frame em uma animação
	protected float temporizadorAnimacao;

    // Usados para animação de derrota
	protected float alfa;

    // posição do inimigo
	protected int posX;
	protected int posY;

	// Inventário de habilidades do protagonista.
    protected Habilidade habilidades[];

    public static enum Animacao
	{
		NENHUM,
		MORTE,
		ATACANDO,
		ATACADO;
	}

	// Métodos da classe Personagem:
	//
	// protected Personagem()
	// public void Desenhar(SpriteBatch batch, BitmapFont font)
	// public void Atualizar()
	// public void SetAnimacaoAtual(Animacao novaAnimacao)
	// protected void AnimacaoNenhum()
	// protected void AnimacaoMorte()
	// protected void AnimacaoAtacando()
	// protected void AnimacaoAtacado()

    protected Personagem()
    {
		morto = false;

        animacoesEmProgresso = true;
        possuiRodada = false;
        animacaoAtual = Animacao.NENHUM;
    }

    // Desenhar o personagem e sua vida.
    public void Desenhar(SpriteBatch batch, BitmapFont font)
    {
		batch.setColor(1, 1, 1, alfa);
        batch.draw(spriteAtual, posX, posY);
		batch.setColor(1, 1, 1, 1);

		// batch.draw(efeitoSprite, posX, posY);

		font.setColor(1, 1, 1, alfa);
		font.draw(batch, vidaAtual + " / " + vidaMax, posX + 35, posY - 10);
		font.setColor(1, 1, 1, 1);
    }

    // Função para atualizar o personagem.
	public void Atualizar()
	{
		temporizadorAnimacao = temporizadorAnimacao - Gdx.graphics.getDeltaTime();

		switch (animacaoAtual)
		{
			case NENHUM:	AnimacaoNenhum();		break;
			case MORTE: 	AnimacaoMorte(); 		break;
			case ATACANDO: 	AnimacaoAtacando(); 	break;
			case ATACADO: 	AnimacaoAtacado();	 	break;
		}
	}

	// Método para controlar a animação do personagem.
	public void SetAnimacaoAtual(Animacao novaAnimacao)
	{
		animacaoAtual = novaAnimacao;

		if (vidaAtual <= 0)
		{
			animacaoAtual = Animacao.MORTE;
		}

		// Se um personagem tiver alguma animação que não seja NENHUM, que dizer que têm animações nesse frame.
		switch (animacaoAtual)
		{
			case NENHUM:
                temporizadorAnimacao = 1;
				spriteAtual = parado1;
                break;
            case ATACANDO:
                temporizadorAnimacao = 3;
				spriteAtual = atacando;
                break;
			case ATACADO:
				temporizadorAnimacao = 2;
				spriteAtual = atacado;
				break;
			case MORTE:
				temporizadorAnimacao = 5;
				spriteAtual = atacado;
				break;
		}
	}

    // Métodos para cada das animações dos personagems. 
    // Todas as animações são usadas pelos inimigos, algumas são sobreescritas pelo protagonista.
	protected void AnimacaoNenhum()
	{
		if (temporizadorAnimacao < 0)
		{
			if (spriteAtual != parado1)
			{
				spriteAtual = parado1;
			}
			else if (spriteAtual != parado2)
			{
				spriteAtual = parado2;
			}
			
			temporizadorAnimacao = 1;
		}
	}

	protected void AnimacaoMorte()
	{
		animacoesEmProgresso = true;
		temporizadorAnimacao = temporizadorAnimacao - Gdx.graphics.getDeltaTime();

		alfa = alfa - Gdx.graphics.getDeltaTime();

		if (temporizadorAnimacao < 0)
		{
			morto = true;
			SetAnimacaoAtual(Animacao.NENHUM);
		}
	}
	
	protected void AnimacaoAtacando()
	{
		animacoesEmProgresso = true;
		if (temporizadorAnimacao < 0)
        {
            SetAnimacaoAtual(Animacao.NENHUM);
        }
	}

	protected void AnimacaoAtacado()
	{
		animacoesEmProgresso = true;
		if (temporizadorAnimacao < 0)
        {
            SetAnimacaoAtual(Animacao.NENHUM);
        }
	}
}