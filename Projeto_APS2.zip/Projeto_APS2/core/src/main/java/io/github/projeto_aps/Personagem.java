package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public abstract class Personagem
{
    // Classe abstrata para Protagonista e Inimigo, usado principalmente para generalizar uso de habilidades.
    // (Personagem -> Personagem invés de Inimigo -> Protagonista ou Protagonista -> Inimigo)

	// stats...
    protected String nome;
    protected boolean possuiRodada;
	protected boolean morto;
    protected int vidaMax;
    protected int vidaAtual;
	protected int energia;
	protected int energiaPorRodada;
	protected int ataque;
	protected int defesa;

    // Variáveis para o uso de habilidades.
    static protected boolean animacoesEmProgresso;

    // Sprites para animação
	private final static Texture barraDeVida = new Texture("barra.png");
	protected Texture parado1;
	protected Texture parado2;
    protected Texture atacando;
	protected Texture efeito;
	protected Texture atacado;
	protected Texture spriteAtual;
    
    // Essa variável mantém conta da animação sendo tocada atualmente
	protected Animacao animacaoAtual;

    // Variável que mantém conta de quantos segundos para trocar o frame em uma animação
	protected float temporizadorAnimacao;

    // Usados para animação de derrota
	protected float alfa;
	protected float r;
	protected float g;
	protected float b;

    // posição do inimigo
	protected int posX;
	protected int posY;

	// Inventário de habilidades do protagonista.
    protected Habilidade habilidades[];

    public static enum Animacao
	{
		NENHUM,
		MORTE,
		ATACANDO,
		ATACADO,
		BUFF,
		DEBUFF;
	}

	// Métodos da classe Personagem:
	//
	// protected Personagem()
	// public void Desenhar(SpriteBatch batch, BitmapFont font)
	// public void Atualizar()
	// public void SetAnimacaoAtual(Animacao novaAnimacao)
	// protected void AnimacaoNenhum()
	// protected void AnimacaoMorte()
	// protected void AnimacaoAtacando()
	// protected void AnimacaoAtacado()

    protected Personagem()
    {
		morto = false;

        animacoesEmProgresso = true;
        possuiRodada = false;
        animacaoAtual = Animacao.NENHUM;
		r = 1;
		g = 1;
		b = 1;
    }

    // Desenhar o personagem e sua vida.
    public void Desenhar(SpriteBatch batch, BitmapFont font)
    {
		batch.setColor(r, g, b, alfa);
        batch.draw(spriteAtual, posX, posY);
		batch.draw(barraDeVida, posX, posY - 34);
		batch.setColor(1, 1, 1, 1);

		// batch.draw(efeitoSprite, posX, posY);

		font.setColor(0, 0, 0, alfa);
		font.draw(batch, vidaAtual + " / " + vidaMax, posX + 10, posY - 10);
		font.setColor(0, 0, 0, 1);
    }

    // Função para atualizar o personagem.
	public void Atualizar()
	{
		temporizadorAnimacao = temporizadorAnimacao - Gdx.graphics.getDeltaTime();

		switch (animacaoAtual)
		{
			case NENHUM:	AnimacaoNenhum();		break;
			case MORTE: 	AnimacaoMorte(); 		break;
			case ATACANDO: 	AnimacaoAtacando(); 	break;
			case ATACADO: 	AnimacaoAtacado();	 	break;
			case BUFF: 		AnimacaoBuff();		 	break;
			case DEBUFF: 	AnimacaoDebuff();	 	break;
		}
	}

	// Método para controlar a animação do personagem.
	public void SetAnimacaoAtual(Animacao novaAnimacao)
	{
		animacaoAtual = novaAnimacao;

		if (vidaAtual <= 0)
		{
			animacaoAtual = Animacao.MORTE;
		}

		// Se um personagem tiver alguma animação que não seja NENHUM, que dizer que têm animações nesse frame.
		switch (animacaoAtual)
		{
			case NENHUM:
                temporizadorAnimacao = 1;
				spriteAtual = parado1;
				r = g = b = 1;
                break;
            case ATACANDO:
                temporizadorAnimacao = 3;
				spriteAtual = atacando;
                break;
			case ATACADO:
				temporizadorAnimacao = 2;
				spriteAtual = atacado;
				g = b = 0;
				break;
			case MORTE:
				temporizadorAnimacao = 5;
				spriteAtual = atacado;
				break;
			case BUFF:
				temporizadorAnimacao = 3;
				spriteAtual = efeito;
				break;
			case DEBUFF:
				temporizadorAnimacao = 3;
				spriteAtual = atacado;
				break;
		}
	}

    // Métodos para cada das animações dos personagems. 
    // Todas as animações são usadas pelos inimigos, algumas são sobreescritas pelo protagonista.
	protected void AnimacaoNenhum()
	{
		if (temporizadorAnimacao < 0)
		{
			if (spriteAtual != parado1)
			{
				spriteAtual = parado1;
			}
			else if (spriteAtual != parado2)
			{
				spriteAtual = parado2;
			}
			
			temporizadorAnimacao = 1;
		}
	}

	protected void AnimacaoMorte()
	{
		animacoesEmProgresso = true;
		temporizadorAnimacao = temporizadorAnimacao - Gdx.graphics.getDeltaTime();

		alfa = alfa - Gdx.graphics.getDeltaTime();

		if (temporizadorAnimacao < 0)
		{
			morto = true;
			SetAnimacaoAtual(Animacao.NENHUM);
		}
	}
	
	protected void AnimacaoAtacando()
	{
		animacoesEmProgresso = true;
		if (temporizadorAnimacao < 1)
        {
			spriteAtual = parado1;

			if(temporizadorAnimacao < 0)
			{
				SetAnimacaoAtual(Animacao.NENHUM);
			}
        }
	}

	protected void AnimacaoAtacado()
	{
		animacoesEmProgresso = true;

		g = g + Gdx.graphics.getDeltaTime();
		b = g;
		System.out.println(g);

		if (temporizadorAnimacao < 0)
        {
            SetAnimacaoAtual(Animacao.NENHUM);
        }
	}
	
	protected void AnimacaoBuff()
	{
		animacoesEmProgresso = true;

		float pi = 3.14f;
		float hz = 1f;
		r = 0.5f * (1 + (float)Math.sin(2 * pi * hz * temporizadorAnimacao));
		b = r;

		if (temporizadorAnimacao < 0)
        {
            SetAnimacaoAtual(Animacao.NENHUM);
        }
	}
	
	protected void AnimacaoDebuff()
	{
		animacoesEmProgresso = true;

		float pi = 3.14f;
		float hz = 1f;
		g = 0.5f * (1 + (float)Math.sin(2 * pi * hz * temporizadorAnimacao));
		r = g;

		if (temporizadorAnimacao < 0)
        {
            SetAnimacaoAtual(Animacao.NENHUM);
        }
	}
}