package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import io.github.projeto_aps.JanelaUI.EstadoDaJanela;

public class Habilidade 
{
    // Interface usada para manipular funções como variáveis. (possibilita colocar as habilidades em um array)
    private static interface ReferenciaFuncao 
    {
       // Falta colocar os parâmetros (Personagem alvo, Personagem fonte, mais qualquer informação necessária)
      void Executar(Personagem responsavel, Personagem alvo);
    }

    // Usado para manipular os stats dos personagems
    private static enum Stats
    {
        ATAQUE,
        DEFESA,
        ENERGIA,
        ENERGIA_POR_RODADA,
        VIDA_ATUAL,
        VIDA_MAX;
    }
 
    // Usado para definir o comportamento da habilidade quando ela for criada.
    public static enum HabilidadeID
    {
        ATAQUE_PESADO,
        AUTO_DESTRUICAO,
        INVESTIMENTO,
        CONSCIENTIZACAO,
        PREVENCAO,
        LEGISLACAO,
        FISCALIZACAO,
        MEDIDAS_DIRETAS,
        TERMINO_DO_MANDATO,
        CORRUPCAO,
        BARULHO_INCESSANTE,
        GASES_ESTUFA,
        FUMACA,
        SMOG,
        CHUVA_ACIDA,
        EUTROFIZACAO,
        ALAGAMENTO,
        AGROTOXICO,
        EROSAO,
        DESMATAMENTO,
        DESLIZAMENTO,
        INCENDIO_FLORESTAL,
        CHUVA_DE_CINZAS,
        FUMO_TOXICO,
        QUEIMADA;
    }
    final private static Sound ataque1 = Gdx.audio.newSound(Gdx.files.internal("audio\\hit1.wav"));
    final private static Sound ataque2 = Gdx.audio.newSound(Gdx.files.internal("audio\\hit2.wav"));
    final private static Sound efeito1 = Gdx.audio.newSound(Gdx.files.internal("audio\\up.wav"));
    final private static Sound efeito2 = Gdx.audio.newSound(Gdx.files.internal("audio\\down.wav"));

    // Variável que segura uma referência a uma função. Deixa agente colocar funções dentro de um array no java.
    private ReferenciaFuncao funcao;

    // Informações sobre a instância da habilidade.
    private String nome;
    private String descricao;
    private int energiaCusto;

    static private String mensagem;

    // Variável que segura o índice dessa habilidade no array habilidades[]
    private int indice;

    // Usado para desenhar o texto no estado HABILIDADES em JanelaUI
    private int posX;
    private int posY;

    // Métodos da classe Habilidade:
    //
    // public Habilidade(int indiceNoArray, HabilidadeID tipoDeHabilidade)
    // public boolean Aplicar(Personagem responsavel, Personagem alvo, JanelaUI janealUI)
    // public void Desenhar(SpriteBatch batch, BitmapFont font, int indiceSelecao, char iconeSelecionado, char iconeNaoSelecionado)
    // ...
    // Métodos para cada habilidades do jogo.

    public Habilidade(int indiceNoArray, HabilidadeID tipoDeHabilidade)
    {
        // indice da váriavel dentro da array habilidades[]
        indice = indiceNoArray;

        posX = (indice % 2) * 320 + 70;

        posY = ((indice + 2) / 2) * -50 + 280;

        switch (tipoDeHabilidade)
        {
            case ATAQUE_PESADO: 
                funcao = this::AtaquePesado;
                energiaCusto = 10;
                nome = " Ataque Pesado";
                descricao = "Teste";
                break;
            case AUTO_DESTRUICAO:
                energiaCusto = 0;
                funcao = this::AutoDestruicao;
                nome = " Auto Destruição";
                descricao = "Teste";
                break;
            case INVESTIMENTO:
                funcao = this::Investimento;
                energiaCusto = 8;
                nome = " Investimento";
                descricao = "Aumentar quantidade de energia ganhada toda rodada por 2.";
                break;
            case CONSCIENTIZACAO:
                funcao = this::Conscientizacao;
                energiaCusto = 6;
                nome = " Conscientização";
                descricao = "Aumentar defesa e ataque por 3.";
                break;
            case PREVENCAO:
                funcao = this::Prevencao;
                energiaCusto = 4;
                nome = " Prevenção";
                descricao = "Diminuir ataque do inimigo por 4.";
                break;
            case LEGISLACAO:
                funcao = this::Legislacao;
                energiaCusto = 4;
                nome = " Legislação";
                descricao = "Diminuir defesa do inimigo por 4.";
                break;
            case FISCALIZACAO:
                funcao = this::Fiscalizacao;
                energiaCusto = 4;
                nome = " Fiscalização";
                descricao = "Atacar inimigo por 10 de dano.";
                break;
            case MEDIDAS_DIRETAS:
                funcao = this::MedidasDiretas;
                energiaCusto = 10;
                nome = " Medidas Diretas";
                descricao = "Atacar inimigo por 30 de dano.";
                break;
            case TERMINO_DO_MANDATO:
                funcao = this::TerminoDoMandato;
                energiaCusto = 0;
                nome = " Término Do Mandato";
                descricao = "Terminar mandato do prefeito.";
                break;
            case CORRUPCAO:
                funcao = this::Corrupcao;
                energiaCusto = 10;
                nome = " Corrupção";
                descricao = "";
                break;
            case BARULHO_INCESSANTE:
                funcao = this::BarulhoIncessante;
                energiaCusto = 2;
                nome = " Barulho Incessante";
                descricao = "";
                break;
            case GASES_ESTUFA:
                funcao = this::GasesEstufa;
                energiaCusto = 6;
                nome = " Gases Estufa";
                descricao = "";
                break;
            case FUMACA:
                funcao = this::Fumaca;
                energiaCusto = 4;
                nome = " Fumaça";
                descricao = "";
                break;
            case SMOG:
                funcao = this::Smog;
                energiaCusto = 8;
                nome = " Ataque Básico";
                descricao = "";
                break;
            case CHUVA_ACIDA:
                funcao = this::ChuvaAcida;
                energiaCusto = 4;
                nome = " Ataque Básico";
                descricao = "";
                break;
            case EUTROFIZACAO:
                funcao = this::Eutrofizacao;
                energiaCusto = 4;
                nome = " Eutrofização";
                descricao = "";
                break;
            case ALAGAMENTO:
                funcao = this::Alagamento;
                energiaCusto = 15;
                nome = " Alagamento";
                descricao = "";
                break;
            case AGROTOXICO:
                funcao = this::Agrotoxicos;
                energiaCusto = 4;
                nome = " Agrotóxicos";
                descricao = "";
                break;
            case EROSAO:
                funcao = this::Erosao;
                energiaCusto = 3;
                nome = " Erosão";
                descricao = "";
                break;
            case DESMATAMENTO:
                funcao = this::Desmatamento;
                energiaCusto = 6;
                nome = " Desmatamento";
                descricao = "";
                break;
            case DESLIZAMENTO:
                funcao = this::Deslizamento;
                energiaCusto = 8;
                nome = " Deslizamento";
                descricao = "";
                break;
            case INCENDIO_FLORESTAL:
                funcao = this::IncendioFlorestal;
                energiaCusto = 6;
                nome = " Incêndio Florestal";
                descricao = "";
                break;
            case CHUVA_DE_CINZAS:
                funcao = this::ChuvaDeCinzas;
                energiaCusto = 4;
                nome = " Chuva Ácida";
                descricao = "";
                break;
            case FUMO_TOXICO:
                funcao = this::FumoToxico;
                energiaCusto = 3;
                nome = " Fumo Tóxico";
                descricao = "";
                break;
            case QUEIMADA:
                funcao = this::Queimada;
                energiaCusto = 8;
                nome = " Queimada";
                descricao = "";
                break;
        }
    }

    // .Aplicar() pode ser usado em qualquer uma das habilidades Ex: habilidades[5].Aplicar( parâmetros ) funciona.
    // Wrapper para a função definida na interface.
    public boolean Aplicar(Personagem responsavel, Personagem alvo, JanelaUI janelaUI)
    {
        if (responsavel.energia < energiaCusto)
        {
            return false;
        }
        else
        {
            mensagem = responsavel.nome + " usou" + this.nome + "!";
            responsavel.energia = responsavel.energia - energiaCusto;
            funcao.Executar(responsavel, alvo);

            if (responsavel.vidaAtual > responsavel.vidaMax)
            {
                responsavel.vidaAtual = responsavel.vidaMax;
            }
            
            janelaUI.SetEstadoDaJanela(EstadoDaJanela.MENSAGEM);
            janelaUI.MostrarMensagem(mensagem);
            return true;
        }
    }

    public void Desenhar(SpriteBatch batch, BitmapFont font, int indiceSelecao, char iconeSelecionado, char iconeNaoSelecionado)
    {
        if (indice == indiceSelecao)
        {
            font.setColor(com.badlogic.gdx.graphics.Color.BLACK);
            font.draw(batch, iconeSelecionado + nome + " (" + energiaCusto + ")", posX, posY);
        }
        else
        {
            font.setColor(com.badlogic.gdx.graphics.Color.GRAY);
            font.draw(batch, iconeNaoSelecionado + nome + " (" + energiaCusto + ")", posX, posY);
        }
    }

    public String GetDescricao()
    {
        return descricao;
    }

    private void AplicarDano(Personagem responsavel, Personagem alvo, int danoBase, boolean ataqueForte)
    {
        ataque1.stop();
        ataque2.stop();
        efeito1.stop();
        efeito2.stop();

        if (ataqueForte)
        {
            ataque2.play(1);
        }
        else
        {
            ataque1.play(1);
        }

        int danoFinal = danoBase + responsavel.ataque - alvo.defesa;
        if (danoFinal < 0) {danoFinal = 0;}
        alvo.vidaAtual = alvo.vidaAtual - danoFinal;

        mensagem = mensagem + "\n" + alvo.nome + " recebeu " + danoFinal + " de dano!";

        responsavel.SetAnimacaoAtual(Personagem.Animacao.ATACANDO);
        alvo.SetAnimacaoAtual(Personagem.Animacao.ATACADO);
    }

    private void ModificarStats(Personagem responsavel, Personagem alvo, int quantidade, boolean aumentarStats, Stats tipoDeStat)
    {
        int sinalNum;
        String modTexto;
        String statTexto;
        
        mensagem = mensagem +"\n";

        ataque1.stop();
        ataque2.stop();
        efeito1.stop();
        efeito2.stop();

        if (aumentarStats)
        {
            efeito1.play(1);
            sinalNum = 1;
            modTexto = " aumentou";
        }
        else
        {
            efeito2.play(1);
            sinalNum = -1;
            modTexto = " diminuiu";
        }

        switch (tipoDeStat)
        {
            case ATAQUE: 
                alvo.ataque = alvo.ataque + quantidade * sinalNum; 
                statTexto = "O ataque de ";
                break;
            case DEFESA: 
                alvo.defesa = alvo.defesa + quantidade * sinalNum;
                statTexto = "A defesa de ";
                break;
            case ENERGIA: 
                alvo.energia = alvo.energia + quantidade * sinalNum;
                statTexto = "A energia de ";
                break;
            case ENERGIA_POR_RODADA: 
                alvo.energiaPorRodada = alvo.energiaPorRodada + quantidade * sinalNum; 
                statTexto = "A energia por rodada de ";
                break;
            case VIDA_ATUAL: 
                alvo.vidaAtual = alvo.vidaAtual + quantidade * sinalNum; 
                statTexto = "A vida de ";
                break;
            case VIDA_MAX: 
                alvo.vidaMax = alvo.vidaMax + quantidade * sinalNum; 
                statTexto = "A vida máxima de ";
                break;
            default:
                statTexto = "Nada de ";
                break;
        }
        responsavel.SetAnimacaoAtual(Personagem.Animacao.ATACANDO);
        mensagem = mensagem + statTexto + alvo.nome + modTexto + " por " + quantidade + "!";
    }

    // As habilidades que os personagems podem usar.
    // Detalhe: Se o jogador não tiver energia o suficiente, 
    // não cobre a energia e não faça nada, talvez mande algum feedback como um som.
    private void AtaquePesado(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 9999, true);
    }

    private void AutoDestruicao(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, responsavel, 9999, true);
    }

    private void Investimento(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 2, true, Stats.ENERGIA);
    }

    private void Conscientizacao(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 3, true, Stats.ATAQUE);
        ModificarStats(responsavel, responsavel, 3, true, Stats.DEFESA);
    }
    
    private void Prevencao(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, alvo, 4, true, Stats.ATAQUE);
    }

    private void Legislacao(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, alvo, 4, false, Stats.DEFESA);
    }

    private void Fiscalizacao(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 10, false);
    }

    private void MedidasDiretas(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 30, true);
    }

    private void Corrupcao(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 20, false);
        ModificarStats(responsavel, responsavel, 10, true, Stats.ATAQUE);
        ModificarStats(responsavel, responsavel, 10, true, Stats.DEFESA);
    }

    private void TerminoDoMandato(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 99999999, true);
    }

    private void BarulhoIncessante(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 3, false);
    }

    private void GasesEstufa(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 1, false, Stats.DEFESA);
        ModificarStats(responsavel, responsavel, 2, true, Stats.ENERGIA_POR_RODADA);
    }

    private void Fumaca(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, alvo, 3, false, Stats.DEFESA);
    }

    private void Smog(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, alvo, 3, false, Stats.DEFESA);
        ModificarStats(responsavel, alvo, 3, false, Stats.ATAQUE);
        ModificarStats(responsavel, responsavel, 3, false, Stats.ENERGIA_POR_RODADA);
    }

    private void ChuvaAcida(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, alvo, 1, false, Stats.DEFESA);
        ModificarStats(responsavel, alvo, 1, false, Stats.ATAQUE);
        ModificarStats(responsavel, alvo, 1, false, Stats.ENERGIA);
        ModificarStats(responsavel, responsavel, 1, true, Stats.DEFESA);
        ModificarStats(responsavel, responsavel, 1, true, Stats.ATAQUE);
    }

    private void Eutrofizacao(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 2, true, Stats.DEFESA);
        ModificarStats(responsavel, responsavel, 2, true, Stats.ATAQUE);
        ModificarStats(responsavel, responsavel, 2, true, Stats.ENERGIA_POR_RODADA);
    }
    
    private void Alagamento(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 10, false);
        ModificarStats(responsavel, responsavel, 2, true, Stats.ENERGIA_POR_RODADA);
    }

    private void Agrotoxicos(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 15, true, Stats.VIDA_ATUAL);
        ModificarStats(responsavel, responsavel, 10, true, Stats.VIDA_MAX);
    }

    private void Erosao(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 3, true, Stats.DEFESA);
        ModificarStats(responsavel, alvo, 1, true, Stats.DEFESA);
    }

    private void Desmatamento(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 10, false);
        ModificarStats(responsavel, responsavel, 1, true, Stats.DEFESA);
    }

    private void Deslizamento(Personagem responsavel, Personagem alvo)
    {
        AplicarDano(responsavel, alvo, 60, true);
        AplicarDano(responsavel, responsavel, 30, true);
    }

    private void IncendioFlorestal(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 1, true, Stats.ATAQUE);
        AplicarDano(responsavel, alvo, 10, false);
    }

    private void ChuvaDeCinzas(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 10, true, Stats.VIDA_ATUAL);
        ModificarStats(responsavel, responsavel, 1, true, Stats.ATAQUE);
    }

    private void FumoToxico(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 1, true, Stats.ATAQUE);
        ModificarStats(responsavel, alvo, 1, false, Stats.ATAQUE);
        ModificarStats(responsavel, alvo, 1, false, Stats.DEFESA);
        ModificarStats(responsavel, alvo, 1, false, Stats.ENERGIA_POR_RODADA);

    }

    private void Queimada(Personagem responsavel, Personagem alvo)
    {
        ModificarStats(responsavel, responsavel, 10, true, Stats.VIDA_MAX);
        ModificarStats(responsavel, responsavel, 10, true, Stats.VIDA_ATUAL);
        AplicarDano(responsavel, alvo, 40, true);
    }
}