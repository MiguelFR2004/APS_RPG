package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.Viewport;

public class TelaMenu implements Screen
{
    
    // TelaMenu é usada para segurar o menu principal do jogo.
    
    // Referência da instância Main, usada para acessar batch e font nas outras classes.
    final Main jogo;

    // usado para desenhar sprites. batch.draw()
    final private SpriteBatch batch;
    // usado para desenhar texto. font.draw()
    final private BitmapFont font;

    // usado para manter a resolução do jogo
    final private Viewport viewport;

    final private Sound beep;

    final private Texture cortina;
    private float temporizadorAnimacao;
    private float alfa;

    private int nivel;

    // Métodos da classe TelaMenu
    //
    // public TelaMenu(final Main jogo)
    // public void render()
    // private void Atualizar()
    // private void Desenhar()
    // private void resize()
    // private void dispose()

    public TelaMenu(final Main jogo)
    {
        // Variáveis estabelecidas em Main. 
        // Todas as variáveis SpriteBatch e BitMapFont devem referênciar o mesmo objeto criado no Main.
        this.jogo = jogo;
        batch = this.jogo.getSpriteBatch();
        font  = this.jogo.getFont();
        viewport = this.jogo.getViewport();
        viewport.apply();

        beep = Gdx.audio.newSound(Gdx.files.internal("audio\\beep.wav"));
        cortina = new Texture("cortina.png");
        temporizadorAnimacao = 0;
        alfa = 1;

        nivel = 0;
    }

    // Loop do jogo acontece na função render() todo frame.
    @Override
    public void render(float delta)
    {
        // Atualizar a lógica do jogo.
        Atualizar(delta);
        // Iniciar SpriteBatch batch e desenhar os sprites.
        Desenhar();
    }

    // Lógica do jogo
    private void Atualizar(float delta)
    {
        if (nivel == 0)
        {
            if (alfa == 0)
            {
                if (Gdx.input.isKeyJustPressed(Keys.NUM_1)) // DEBUG
                {
                    nivel = 1;
                    beep.play(1);
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_2)) // DEBUG
                {
                    nivel = 2;
                    beep.play(1);
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_3)) // DEBUG
                {
                    nivel = 3;
                    beep.play(1);
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_4)) // DEBUG
                {
                    nivel = 4;
                    beep.play(1);
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_5)) // DEBUG
                {
                    nivel = 5;
                    beep.play(1);
                }
            }
            else
            {
                temporizadorAnimacao = temporizadorAnimacao - delta;

                if (temporizadorAnimacao < 0)
                {
                    alfa = alfa - delta;
                
                    if (alfa < 0)
                    {
                        alfa = 0;
                        temporizadorAnimacao = 1;
                    }
                }
            }
        }
        else
        {
            alfa = alfa + delta;
                
            if (alfa > 1)
            {
                temporizadorAnimacao = temporizadorAnimacao - delta;
            
                if (temporizadorAnimacao < 0)
                {
                    jogo.setScreen(new TelaCutscene(jogo, nivel));
                }
            }
        }
    }

    private void Desenhar()
    {
        // Preparar novo frame
        jogo.LimparTela();

        // Começar desenho, todos os batch.Draw() e font.Draw() acontecem depois do .begin() e antes do .end();
        batch.begin();
        font.setColor(1, 1, 1, 1);
        font.draw(batch, "Aperte 1-5 para iniciar os níveis.", 200, 200);
        batch.setColor(1, 1, 1, alfa);
        batch.draw(cortina, 0, 0);
        batch.setColor(1, 1, 1, 1);
        batch.end();

        // Atualizar as bordas rolantes
        jogo.AtualizarBordas();
    }

    @Override
    public void resize(int width, int height)
    {
        viewport.update(width, height);
    }

    @Override
    public void dispose()
    {
        batch.dispose();
        font.dispose();
    }

    @Override
    public void show()
    {

    }

    @Override
    public void hide()
    {

    }

    @Override
    public void pause()
    {

    }

    @Override
    public void resume()
    {

    }
}
