package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.Viewport;

public class TelaMenu implements Screen
{
    final Main jogo;

    final private SpriteBatch batch;
    final private BitmapFont font;
    final private Viewport viewport;

    final private Sound beep = Gdx.audio.newSound(Gdx.files.internal("audio\\beep.wav"));
    final private Texture menu = new Texture("MENU-002.png");
    final private Texture fundo = new Texture("FUNDO-002.png");
    final private Texture cortina = new Texture("cortina.png");;
    private float temporizadorAnimacao;
    private float alfa;
    private char indicador;

    private int nivel;

    // Métodos da classe TelaMenu
    //
    // public TelaMenu(final Main jogo)
    // public void render()
    // private void Atualizar()
    // private void Desenhar()
    // private void resize()
    // private void dispose()

    public TelaMenu(final Main jogo)
    {
        // Variáveis estabelecidas em Main. 
        // Todas as variáveis SpriteBatch e BitMapFont devem referênciar o mesmo objeto criado no Main.
        this.jogo = jogo;
        batch = this.jogo.getSpriteBatch();
        font  = this.jogo.getFont();
        viewport = this.jogo.getViewport();
        viewport.apply();

        temporizadorAnimacao = 0;
        indicador = ' ';
        alfa = 1;
        nivel = 0;
    }

    // Loop do jogo acontece na função render() todo frame.
    @Override
    public void render(float delta)
    {
        // Atualizar a lógica do jogo.
        Atualizar(delta);
        // Iniciar SpriteBatch batch e desenhar os sprites.
        Desenhar();
    }

    // Lógica do jogo
    private void Atualizar(float delta)
    {
        if (nivel == 0)
        {
            if (alfa == 0)
            {
                if (Gdx.input.isKeyJustPressed(Keys.NUM_1) || Gdx.input.isKeyJustPressed(Keys.ENTER))
                {
                    nivel = 1;
                    beep.play(1);
                    temporizadorAnimacao = 1;
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_2))
                {
                    nivel = 2;
                    beep.play(1);
                    temporizadorAnimacao = 1;
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_3))
                {
                    nivel = 3;
                    beep.play(1);
                    temporizadorAnimacao = 1;
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_4))
                {
                    nivel = 4;
                    beep.play(1);
                    temporizadorAnimacao = 1;
                }
                if (Gdx.input.isKeyJustPressed(Keys.NUM_5))
                {
                    nivel = 5;
                    beep.play(1);
                    temporizadorAnimacao = 1;
                }

                temporizadorAnimacao = temporizadorAnimacao - delta;
                if (temporizadorAnimacao < 0)
                {
                    if (indicador == '_')
                    {
                        indicador = ' ';
                    }
                    else
                    {
                        indicador = '_';
                    }
                    temporizadorAnimacao = 1;
                }
            }
            else
            {
                temporizadorAnimacao = temporizadorAnimacao - delta;

                if (temporizadorAnimacao < 0)
                {
                    alfa = alfa - delta;
                
                    if (alfa < 0)
                    {
                        alfa = 0;
                        temporizadorAnimacao = 1;
                    }
                }
            }
        }
        else
        {
            alfa = alfa + delta;
                
            if (alfa > 1)
            {
                temporizadorAnimacao = temporizadorAnimacao - delta;
            
                if (temporizadorAnimacao < 0)
                {
                    jogo.setScreen(new TelaCutscene(jogo, nivel));
                }
            }
        }
    }

    private void Desenhar()
    {
        // Preparar novo frame
        jogo.LimparTela();

        // Começar desenho, todos os batch.Draw() e font.Draw() acontecem depois do .begin() e antes do .end();
        batch.begin();
        batch.draw(fundo, 0, 0);
        batch.draw(menu, 150, 0);
        font.setColor(0, 0, 0, 1);
        font.draw(batch, "Mal Ambientado" + indicador, 400, 500);
        font.draw(batch, "Aperte ENTER para começar", 400, 150);
        batch.setColor(1, 1, 1, alfa);
        batch.draw(cortina, 0, 0);
        batch.setColor(1, 1, 1, 1);
        batch.end();

        // Atualizar as bordas rolantes
        jogo.AtualizarBordas();
    }

    @Override
    public void resize(int width, int height)
    {
        viewport.update(width, height);
    }

    @Override
    public void dispose()
    {
        batch.dispose();
        font.dispose();
    }

    @Override
    public void show()
    {

    }

    @Override
    public void hide()
    {

    }

    @Override
    public void pause()
    {

    }

    @Override
    public void resume()
    {

    }
}
