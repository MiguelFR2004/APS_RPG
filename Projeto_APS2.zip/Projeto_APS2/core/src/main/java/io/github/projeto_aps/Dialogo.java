package io.github.projeto_aps;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Dialogo 
{
    final private String texto;

    final private Texture texturaProtagonista;
    final private Texture texturaPersonagem;

    // Métodos da classe Dialogo:
    //
    // public Dialogo(String texto, Texture texturaProtagonista, Texture texturaPersonagem)
    // public void Desenhar(SpriteBatch batch, BitmapFont font)

    public Dialogo(String texto, Texture texturaProtagonista, Texture texturaPersonagem)
    {
        this.texto = texto;
        this.texturaProtagonista = texturaProtagonista;
        this.texturaPersonagem = texturaPersonagem;
    }

    public void Desenhar(SpriteBatch batch, BitmapFont font)
    {
        batch.draw(texturaProtagonista, 0, 0);
        batch.draw(texturaPersonagem, 0, 0);
        font.setColor(0,0,0,1);
        font.draw(batch, texto, 50, 50);
        font.setColor(0,0,0,1);
    }
}
