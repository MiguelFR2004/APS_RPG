package io.github.projeto_aps;

// Classes do libGDX
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import io.github.projeto_aps.Inimigo.TipoDeInimigo;

public class SistemaJogo
{
	// SistemaJogo processa as mecânicas do jogo.
	// Responsável por controlar as rodadas e manipular os personagems (inimigos e protagonista).

	// Enumerador para controlar o estado do jogo. (Máquina de estados finita)
	// Cada estado chama uma função que controla o comportamento do jogo.
	private enum EstadoDoJogo
	{
		APLICAR_RODADA,
		PROCESSAR_RODADA,
		APLICAR_JOGADOR,
		PROCESSAR_JOGADOR,
		APLICAR_INIMIGOS,
		PROCESSAR_INIMIGOS,
		CORTINAS;
	}

	// Variável para segurar o estado atual do jogo.
	private EstadoDoJogo estadoDoJogo;
	// Mantém conta da rodada atual.
	private int rodada;

	private Main jogo;

	// Mantém conta do nívle atual. Ar = 1 Agua = 2 Terra = 3 Fogo = 4 Final = 5
	final private int nivel;

	private Protagonista protagonista;
	private Inimigo inimigo;

	// Classe que controla o UI do jogo.
	private JanelaUI janelaUI;

	final private SpriteBatch batch;
	final private BitmapFont font;

	// Usado para escurecer a tela no inicio e fim do jogo.
	final private Texture cortina;
	final private Texture fundo;
	private float alfa;

	final private Sound beep;

	// Métodos da classe SistemaJogo:
	//
	// public SistemaJogo(final Main jogo, int nivel)
	// public void Atualizar()
	// public void Desenhar()
	// private void AplicarRodada()
	// private void ProcessarRodada()
	// private void AplicarJogador()
	// private void ProcessarJogador()
	// private void AplicarInimigos()
	// private void ProcessarInimigos()
	// private void ProcessarCortinas()
	
	public SistemaJogo(final Main jogo, int nivel)
	{
		// Variáveis de controle das rodadas.
		estadoDoJogo = EstadoDoJogo.CORTINAS;
		rodada = 0;
		this.nivel = nivel;

		this.jogo = jogo;

		beep = Gdx.audio.newSound(Gdx.files.internal("audio\\beep.wav"));
		cortina = new Texture("cortina.png");

		if (nivel != 5)
		{
			fundo = new Texture("FUNDO-000.png");
		}
		else
		{
			fundo = new Texture("FUNDO-001.png");
		}

		alfa = 1;
	
		// Classes do jogo
		protagonista = new Protagonista(this.nivel);
		janelaUI = new JanelaUI(beep);
		switch (this.nivel)
		{
			case 1: inimigo = new Inimigo(TipoDeInimigo.AR); 	break;
			case 2: inimigo = new Inimigo(TipoDeInimigo.AGUA); 	break;
			case 3: inimigo = new Inimigo(TipoDeInimigo.TERRA); break;
			case 4: inimigo = new Inimigo(TipoDeInimigo.FOGO); 	break;
			case 5: inimigo = new Inimigo(TipoDeInimigo.CHEFE); break;
		}

		// Objetos para desenho
		batch = jogo.getSpriteBatch();
		font = jogo.getFont();
	}

    public void Atualizar()
    {
		// Checar se têm animações ativas nesse frame. Fazer verdade se uma animação for tocada.
		Protagonista.animacoesEmProgresso = false;

		protagonista.Atualizar();
		inimigo.Atualizar();
		
		if (protagonista.morto || inimigo.morto)
		{
			estadoDoJogo = EstadoDoJogo.CORTINAS;
			janelaUI.SetEstadoDaJanela(JanelaUI.EstadoDaJanela.MENSAGEM);
			janelaUI.MostrarMensagem("");
		}

		// Controle da máquina de estados:
		// Os estados APLICAR lidam mais com lógica, qualquer coisa que precisa ser processado só uma vez (Ex: Aplicar Ataque)
		// Os estados PROCESSAR lidam com processos que acontecem ao longo de vários frames como animações e input.
		switch (estadoDoJogo)
		{
			case APLICAR_RODADA: 		AplicarRodada(); 		break; 
			case PROCESSAR_RODADA: 		ProcessarRodada(); 		break;
			case APLICAR_JOGADOR: 		AplicarJogador(); 		break;
			case PROCESSAR_JOGADOR: 	ProcessarJogador(); 	break;
			case APLICAR_INIMIGOS: 		AplicarInimigos(); 		break;
			case PROCESSAR_INIMIGOS: 	ProcessarInimigos(); 	break;
			case CORTINAS:				ProcessarCortinas();	break;
		}
    }

	public void Desenhar()
	{
		// Ordem de desenho importa. Texturas desenhadas primeiras ficam atrás de texturas desenhadas depois.
		batch.draw(fundo, 0, 0);

		protagonista.Desenhar(batch, font);
		inimigo.Desenhar(batch, font);
		janelaUI.Desenhar(batch, font, protagonista);

		batch.setColor(1, 1, 1, alfa);
		batch.draw(cortina, 0, 0);
		batch.setColor(1, 1, 1, 1);
	}

	// --- Métodos para o estado do jogo. -----------------------------------------------------------------------------------------------------------
	private void AplicarRodada()
	{
		// Começo da nova rodada.
		rodada++;
		
		// Reativar as rodadas do protagonista e dos inimigos no ínicio de uma nova rodada.
		protagonista.possuiRodada = true;
		protagonista.energia = protagonista.energia + protagonista.energiaPorRodada;

		inimigo.possuiRodada = true;
		inimigo.energia = inimigo.energia + inimigo.energiaPorRodada;

		// Preparar janela para mostrar uma mensagem.
		janelaUI.SetEstadoDaJanela(JanelaUI.EstadoDaJanela.MENSAGEM);

		// Iniciar processamento da rodada.
		estadoDoJogo = EstadoDoJogo.PROCESSAR_RODADA;
	}

	private void ProcessarRodada()
	{
		janelaUI.MostrarMensagem("Começando rodada " + rodada);

		if (Gdx.input.isKeyJustPressed(Keys.SPACE) || Gdx.input.isKeyJustPressed(Keys.ENTER))
		{
			estadoDoJogo = EstadoDoJogo.APLICAR_JOGADOR;
			beep.play(1);
		}
	}

	private void AplicarJogador()
	{
		// Preparar janela para receber input.
		janelaUI.SetEstadoDaJanela(JanelaUI.EstadoDaJanela.INICIO);

		// Iniciar processamento da vez do jogador.
		estadoDoJogo = EstadoDoJogo.PROCESSAR_JOGADOR;
	}

	private void ProcessarJogador()
	{
		// Atualizar a rodada do jogador.
		janelaUI.Atualizar(protagonista, inimigo);

		// Se o jogador terminou a rodada, começar vez dos inimigos.
		if (protagonista.possuiRodada == false)
		{
			estadoDoJogo = EstadoDoJogo.APLICAR_INIMIGOS;
		}
	}

	private void AplicarInimigos()
	{
		// Preparar janela para mostrar uma mensagem.
		janelaUI.SetEstadoDaJanela(JanelaUI.EstadoDaJanela.MENSAGEM);

		if (inimigo.possuiRodada)
		{
			estadoDoJogo = EstadoDoJogo.PROCESSAR_INIMIGOS;
			inimigo.JogarRodada(protagonista, janelaUI);
		}
		else
		{
			estadoDoJogo = EstadoDoJogo.APLICAR_RODADA;
		}
	}

	private void ProcessarInimigos()
	{
		if (!Personagem.animacoesEmProgresso)
		{
			estadoDoJogo = EstadoDoJogo.APLICAR_INIMIGOS;
		}
	}

	private void ProcessarCortinas()
	{
		if (!protagonista.morto && !inimigo.morto)
		{
			alfa = alfa - Gdx.graphics.getDeltaTime();
			if (alfa < 0)
			{
				alfa = 0;
				estadoDoJogo = EstadoDoJogo.APLICAR_RODADA;
			}
		}
		else
		{
			alfa = alfa + Gdx.graphics.getDeltaTime();
			if (alfa > 1)
			{
				if (protagonista.morto)
				{
					jogo.setScreen(new TelaMenu(jogo));
				}
				if (inimigo.morto)
				{
					jogo.setScreen(new TelaCutscene(jogo, nivel + 1));
				}
			}
		}
	}
}