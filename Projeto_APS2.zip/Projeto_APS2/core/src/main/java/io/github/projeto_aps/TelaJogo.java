package io.github.projeto_aps;

// Classes do libGDX
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.Viewport;

// Tela que mostra o jogo principal
public class TelaJogo implements Screen{

    // TelaJogo tem a função de segurar tudo que acontece no jogo de rpg em si.
    
    // Referência da instância Main, usada para acessar batch e font nas outras classes.
    final Main jogo;

    // usado para desenhar sprites. batch.draw()
    final private SpriteBatch batch;
    // usado para desenhar texto. font.draw()
    final private BitmapFont font;

    // usado para manter a resolução do jogo
    final private Viewport viewport;

    // usado para calculara a lógica do mundo jogo.
    SistemaJogo sistemaJogo;

    // Métodos da classe Telajogo:
    //
    // public Telajogo(final Main jogo, int nivel)
    // public void resize(int width, int nivel)
    // public void dispose()
    // public void render(float delta)
    // private void Atualizar()
    // private void Desenhar()

    public TelaJogo(final Main jogo, int nivel)
    {
        // Variáveis estabelecidas em Main. 
        // Todas as variáveis SpriteBatch e BitMapFont devem referênciar o mesmo objeto criado no Main.
        this.jogo = jogo;
        batch = this.jogo.getSpriteBatch();
        font  = this.jogo.getFont();
        viewport = this.jogo.getViewport();
        viewport.apply();
    
        // Lógica do jogo acontece dentro daqui
        sistemaJogo = new SistemaJogo(this.jogo, nivel);
    }

    // Método chamado quando a janela é redimensionada.
    @Override
    public void resize(int width, int height)
    {
        viewport.update(width, height);
    }

    // Variáveis a serem jogadas fora ao trocar de Tela.
    @Override
    public void dispose()
    {
        batch.dispose();
        font.dispose();
    }

    // Loop do jogo acontece na função render() todo frame.
    @Override
    public void render(float delta)
    {
        // Atualizar a lógica do jogo.
        Atualizar();
        // Iniciar SpriteBatch batch e desenhar os sprites.
        Desenhar();
    }

    // Lógica do jogo
    private void Atualizar()
    {
        sistemaJogo.Atualizar();

        // Pseudocódigo para possíveis menus, não obrigatório.
        // Uma imagem de borda e um botão que mande para a TelaMenu seria o suficiente para os menus.
        /*
        SE o jogo estiver ativo
		{
			sistemaJogo.Atualizar();
		}
        SE o jogo estiver pausado
        {
            menuPausa.Atualizar();
        }
		SE o jogador perdeu
		{
			menuGameOver.Atualizar();
		}
        SE o jogador ganhou
        {
            menuVitoria.Atualizar();
        }
        */
    }

    private void Desenhar()
    {
        // Preparar novo frame
        jogo.LimparTela();

        // Começar desenho, todos os batch.Draw() e font.Draw() acontecem depois do .begin() e antes do .end();
        batch.begin();
        sistemaJogo.Desenhar();
        batch.end();

        // Atualizar as bordas rolantes
        jogo.AtualizarBordas();

        // Pseudocódigo para possíveis menus, não obrigatório.
        // Uma imagem de borda e um botão que mande para a TelaMenu seria o suficiente para os menus.
        /*
        SE o jogo estiver ativo
		{
			sistemaJogo.Desenhar();
		}
        SE o jogo estiver pausado
        {
            menuPuasa.Desenhar();
        }
		SE o jogador perdeu
		{
			menuGameOver.Desenhar();
		}
        SE o jogador ganhou
        {
            menuVitoria.Desenhar();
        }
        */
    }

    // Método obrigatório da interface Screen, pode ignorar.
    @Override
    public void show()
    {

    }

    // Método obrigatório da interface Screen, pode ignorar.
    @Override
    public void hide()
    {

    }

    // Método obrigatório da interface Screen, pode ignorar.
    @Override
    public void pause()
    {

    }

    // Método obrigatório da interface Screen, pode ignorar.
    @Override
    public void resume()
    {

    }
}
