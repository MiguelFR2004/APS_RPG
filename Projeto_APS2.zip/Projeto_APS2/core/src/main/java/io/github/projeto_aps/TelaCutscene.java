package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.Viewport;

public class TelaCutscene implements Screen{
    
    // TelaMenu é usada para segurar o menu principal do jogo.
    
    // Referência da instância Main, usada para acessar batch e font nas outras classes.
    final Main jogo;

    final private int nivel;

    // usado para desenhar sprites. batch.draw()
    final private SpriteBatch batch;
    // usado para desenhar texto. font.draw()
    final private BitmapFont font;

    final private Texture barraTexto = new Texture("MENU-001.png");
    final private Texture cortina = new Texture("cortina.png");

    // usado para manter a resolução do jogo
    final private Viewport viewport;

    final private Sound beep;
    
    private float temporizadorAnimacao;
    private float alfa;
    private int indiceDialogo;
    private int quantidadeDialogos;

    private Dialogo[] dialogos;

    // Métodos da classe TelaCutscene:
    //
    // public TelaCutscene
    // public void resize(int width, int height)
    // public void dispose()
    // public void render(float delta)
    // public void Atualizar(float delta)
    // private void Desenhar()

    public TelaCutscene(final Main jogo, int nivel)
    {
        // Variáveis estabelecidas em Main. 
        // Todas as variáveis SpriteBatch e BitMapFont devem referênciar o mesmo objeto criado no Main.
        this.jogo = jogo;
        this.nivel = nivel;
        batch = this.jogo.getSpriteBatch();
        font  = this.jogo.getFont();
        viewport = this.jogo.getViewport();
        viewport.apply();

        beep = Gdx.audio.newSound(Gdx.files.internal("audio\\beep.wav"));
        
        Texture ruido = new Texture("_cutscene\\JORNAL-000.png");
        Texture jornal = new Texture("_cutscene\\JORNAL-001.png");
        Texture cena0;
        Texture cena1;
        Texture cena2;
        Texture cena3;

        switch (this.nivel)
        {
            case 1: 
                cena0 = new Texture("_cutscene\\FUNDO-000.png");
                cena1 = new Texture("_cutscene\\FUNDO-001.png");
                cena2 = new Texture("_cutscene\\FUNDO-002.png");
                quantidadeDialogos = 10;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", cena0);
                dialogos[1] = new Dialogo("Tomas Ibarra: Então... Você se lembra daquele candidato Pedro\nFeito?", cena0);
                dialogos[2] = new Dialogo("Serena Cretaria: Você quer dizer aquele que prometeu desmatar\nos bosques, poluir os rios e aumentar a emissão de carbono da\ncidade em 40%?", cena1);
                dialogos[3] = new Dialogo("Tomas Ibarra: Isso, mas ele também prometeu reduzir a inflação\nem 0.5%", cena0);
                dialogos[4] = new Dialogo("Serena Cretaria: Honestamente eu não sei como alguém assim\nviracandidato, me lembra aquela vez que tivemos um palhaço\ncomo deputado.", cena1);
                dialogos[5] = new Dialogo("Serena Cretaria: Bom, ainda bem que ninguém iria votar pra\nalguem assim, isso tornaria o meu trabalho umas mil vezes\npior...", cena0);
                dialogos[6] = new Dialogo("Tomas Ibarra: Então, ele foi eleito.", cena0);
                dialogos[7] = new Dialogo("...", cena0);
                dialogos[8] = new Dialogo("Serena Cretaria: COMO ASSIM, ELE FOI ELEITO?!", cena2);
                dialogos[9] = new Dialogo("", cena2);
                break;
            case 2:
                quantidadeDialogos = 4;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", ruido);
                dialogos[1] = new Dialogo("Para as notícias ambientais, tivemos uma redução de 30% da\nemissão de carbono devido as normas implementadas essa\nsemana, recebendo enormes agradecimentos dos habitantes da\ncidade de...", jornal);
                dialogos[2] = new Dialogo("", ruido);
                dialogos[3] = new Dialogo("", ruido);
                break;
            case 3:
                cena0 = new Texture("_cutscene\\FUNDO-003.png");
                cena1 = new Texture("_cutscene\\FUNDO-004.png");
                cena2 = new Texture("_cutscene\\FUNDO-005.png");
                cena3 = new Texture("_cutscene\\FUNDO-006.png");
                quantidadeDialogos = 13;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", ruido);
                dialogos[1] = new Dialogo("De volta com as notícias ambientais, nos últimos tempos os\nesforços da secretaria do meio ambiente demonstraram frutos,\ncom o retorno da vida aquática nos rios e lagos ao redor da\ncidade de...", jornal);
                dialogos[2] = new Dialogo("", ruido);
                dialogos[3] = new Dialogo("Serena Cretaria: Espera, espera, espera, recapitulando.", cena0);
                dialogos[4] = new Dialogo("Serena Cretaria: Pedro Feito era na verdade um demônio", cena2);
                dialogos[5] = new Dialogo("Tomas Ibarra: Uhum...", cena1);
                dialogos[6] = new Dialogo("Serena Cretaria: E ele está usando a poluição local para\nmanifestar outros demônios", cena2);
                dialogos[7] = new Dialogo("Tomas Ibarra: Isso...", cena1);
                dialogos[8] = new Dialogo("Serena Cretaria: E eu posso impedir isso, resolvendo os\nproblemas ambientais da cidade para enfraquecer esses\ndemônios?", cena2);
                dialogos[9] = new Dialogo("Tomas Ibarra: É basicamente isso.", cena1);
                dialogos[10] = new Dialogo("Serena Cretaria: E você sabe disso por quê?", cena2);
                dialogos[11] = new Dialogo("Tomas Ibarra: Eu vi no Tok Tik.", cena3);
                dialogos[12] = new Dialogo("", cena3);
                break;
            case 4:
                quantidadeDialogos = 4;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", ruido);
                dialogos[1] = new Dialogo("Agora para as notícias ambientais, as novas políticas de\ndescarte e coleta de lixo coordenadas pela secretaria do meio\nambiente causaram um melhora continua na qualidade de vida de\ntodos os habitantes da cidade de ...", jornal);
                dialogos[2] = new Dialogo("", ruido);
                dialogos[3] = new Dialogo("", ruido);
                break;
            case 5:
                cena0 = new Texture("_cutscene\\FUNDO-007.png");
                cena1 = new Texture("_cutscene\\FUNDO-008.png");
                cena2 = new Texture("_cutscene\\FUNDO-009.png");
                cena3 = new Texture("_cutscene\\FUNDO-010.png");
                quantidadeDialogos = 17;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", ruido);
                dialogos[1] = new Dialogo("Com as notícias ambientais, essa semanas tivemos uma drástica\ndiminuição em queimadas ilegais de lixo, registrando o menor\nquadro em anos melhorando a qualidade de vida dos cidade de...", jornal);
                dialogos[2] = new Dialogo("", ruido);
                dialogos[3] = new Dialogo("Serena Cretaria: Você!", cena0);
                dialogos[4] = new Dialogo("Pedro Feito: Eu?", cena2);
                dialogos[5] = new Dialogo("Serena Cretaria: Você é quem tá acelerando a poluição nessa\ncidade!", cena0);
                dialogos[6] = new Dialogo("Pedro Feito: Eu estou investindo na economia.", cena1);
                dialogos[7] = new Dialogo("Serena Cretaria: Você é quem tá cortando os gastos das\niniciativas ecológicas!", cena0);
                dialogos[8] = new Dialogo("Pedro Feito: Eu estou reduzindo a burocracia.", cena1);
                dialogos[9] = new Dialogo("Serena Cretaria: VOCÊ É UM DEMÔNIO!", cena0);
                dialogos[10] = new Dialogo("Pedro Feito: Fake news.", cena1);
                dialogos[11] = new Dialogo("Tomas Ibarra: Ei, não teve um escândalo aí onde cê foi pego\nembolsando recurso público?", cena2);
                dialogos[12] = new Dialogo("...", cena2);
                dialogos[13] = new Dialogo("Pedro Feito: Tolos mortais...", cena3);
                dialogos[14] = new Dialogo("Pedro Feito: Preparem-se... pela sua...", cena3);
                dialogos[15] = new Dialogo("Pedro Feito: REMOÇÃO!", cena3);
                dialogos[16] = new Dialogo("", cena3);
                break;
            case 6:
                cena0 = new Texture("_cutscene\\FUNDO-011.png");
                cena1 = new Texture("_cutscene\\FUNDO-012.png");
                cena2 = new Texture("_cutscene\\FUNDO-013.png");
                cena3 = new Texture("_cutscene\\FUNDO-014.png");
                quantidadeDialogos = 12;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", cena0);
                dialogos[1] = new Dialogo("Serena Cretaria: AHH...", cena0);
                dialogos[2] = new Dialogo("Serena Cretaria: Isso finalmente acabou.", cena0);
                dialogos[3] = new Dialogo("Tomas Ibarra: Ainda bem", cena0);
                dialogos[4] = new Dialogo("...", cena0);
                dialogos[5] = new Dialogo("Tomas Ibarra: Hey...", cena1);
                dialogos[6] = new Dialogo("Serena Cretaria: Não...", cena2);
                dialogos[7] = new Dialogo("Tomas Ibarra: ... a temporada de eleição está de volta...", cena1);
                dialogos[8] = new Dialogo("Serena Cretaria: Não...", cena2);
                dialogos[9] = new Dialogo("Tomas Ibarra: E você não vai acreditar quem é o candidato no\ntopo das pesquisas...", cena1);
                dialogos[10] = new Dialogo("Serena Cretaria: Eu preciso de férias.", cena3);
                dialogos[11] = new Dialogo("", cena3);
                break;
            default:
                quantidadeDialogos = 2;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", ruido);
                dialogos[1] = new Dialogo("", ruido);
                break;
        }
        temporizadorAnimacao = 1;
        indiceDialogo = 0;
        alfa = 1;
    }

    @Override
    public void resize(int width, int height)
    {
        viewport.update(width, height);
    }

    @Override
    public void dispose()
    {
        batch.dispose();
        font.dispose();
    }

    // Loop do jogo acontece na função render() todo frame.
    @Override
    public void render(float delta)
    {
        // Atualizar a lógica do jogo.
        Atualizar(delta);
        // Iniciar SpriteBatch batch e desenhar os sprites.
        Desenhar();
    }

    // Lógica do jogo
    private void Atualizar(float delta)
    {
        if (indiceDialogo == 0)
        {
            temporizadorAnimacao = temporizadorAnimacao - delta;
            
            if (temporizadorAnimacao < 0)
            {
                if (alfa > 0)
                {
                    alfa = alfa - delta;
                }
                else
                {
                    alfa = 0;
                    temporizadorAnimacao = 2;
                    indiceDialogo++;
                }
            }
        }
        else if (indiceDialogo == quantidadeDialogos - 1)
        {
            alfa = alfa + delta;
                
            if (alfa > 1)
            {
                temporizadorAnimacao = temporizadorAnimacao - delta;
            
                if (temporizadorAnimacao < 0)
                {
                    if (nivel < 6)
                    {
                        jogo.setScreen(new TelaJogo(jogo, nivel));
                    }
                    else
                    {
                        jogo.setScreen(new TelaMenu(jogo));
                    }
                }
            }
        }
        else
        {
            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE) || Gdx.input.isKeyJustPressed(Input.Keys.ENTER))
            {
                beep.play(1);
                indiceDialogo++;
            }
        }   
    }

    private void Desenhar()
    {
        // Preparar novo frame
        jogo.LimparTela();

        // Começar desenho, todos os batch.Draw() e font.Draw() acontecem depois do .begin() e antes do .end();
        batch.begin();
        batch.draw(barraTexto, 0, 0);
        dialogos[indiceDialogo].Desenhar(batch, font);
        batch.setColor(1, 1, 1, alfa);
        batch.draw(cortina, 0, 0);
        batch.setColor(1, 1, 1, 1);
        batch.end();

        // Atualizar as bordas rolantes
        jogo.AtualizarBordas();
    }

    @Override
    public void show()
    {

    }

    @Override
    public void hide()
    {

    }

    @Override
    public void pause()
    {

    }

    @Override
    public void resume()
    {

    }
}
