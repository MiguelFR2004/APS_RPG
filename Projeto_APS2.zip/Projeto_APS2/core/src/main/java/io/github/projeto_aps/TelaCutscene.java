package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.Viewport;

public class TelaCutscene implements Screen{
    
    // TelaMenu é usada para segurar o menu principal do jogo.
    
    // Referência da instância Main, usada para acessar batch e font nas outras classes.
    final Main jogo;

    final private int nivel;

    // usado para desenhar sprites. batch.draw()
    final private SpriteBatch batch;
    // usado para desenhar texto. font.draw()
    final private BitmapFont font;

    // usado para manter a resolução do jogo
    final private Viewport viewport;

    final private Texture fundo;
    final private static Texture protagonista1 = new Texture("_cutscene\\protagonista1.png");
    final private static Texture protagonista2 = new Texture("_cutscene\\protagonista2.png");
    final private static Texture protagonista3 = new Texture("_cutscene\\protagonista3.png");
    final private static Texture personagem1 = new Texture("_cutscene\\personagem1.png");
    final private static Texture personagem2 = new Texture("_cutscene\\personagem2.png");
    final private static Texture personagem3 = new Texture("_cutscene\\personagem3.png");
    final private static Texture vazio = new Texture("_cutscene\\vazio.png");
    final private static Texture barraTexto = new Texture("_cutscene\\barra.png");
    final private static Texture cortina = new Texture("cortina.png");

    final private Sound beep;
    
    private float temporizadorAnimacao;
    private float alfa;
    private int indiceDialogo;
    private int quantidadeDialogos;

    private Dialogo[] dialogos;

    // Métodos da classe TelaCutscene:
    //
    // public TelaCutscene
    // public void resize(int width, int height)
    // public void dispose()
    // public void render(float delta)
    // public void Atualizar(float delta)
    // private void Desenhar()

    public TelaCutscene(final Main jogo, int nivel)
    {
        // Variáveis estabelecidas em Main. 
        // Todas as variáveis SpriteBatch e BitMapFont devem referênciar o mesmo objeto criado no Main.
        this.jogo = jogo;
        this.nivel = nivel;
        batch = this.jogo.getSpriteBatch();
        font  = this.jogo.getFont();
        viewport = this.jogo.getViewport();
        viewport.apply();

        beep = Gdx.audio.newSound(Gdx.files.internal("audio\\beep.wav"));

        switch (this.nivel)
        {
            case 1: 
                fundo = new Texture("_cutscene\\fundo1.png");
                quantidadeDialogos = 10;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", protagonista1, personagem1);
                dialogos[1] = new Dialogo("Personagem: nivel 1 blah blah blah", protagonista1, personagem2);
                dialogos[2] = new Dialogo("Protagonista: 1 blah blah blah", protagonista2, personagem1);
                dialogos[3] = new Dialogo("Personagem: 2 blah blah blah", protagonista1, personagem2);
                dialogos[4] = new Dialogo("Protagonista: 3 blah blah blah", protagonista2, personagem1);
                dialogos[5] = new Dialogo("Personagem: 4 blah blah blah", protagonista1, personagem2);
                dialogos[6] = new Dialogo("Protagonista: 5 blah blah balh", protagonista2, personagem1);
                dialogos[7] = new Dialogo("Personagem: 6 blah blah balh", protagonista1, personagem2);
                dialogos[8] = new Dialogo("Protagonista: >:(", protagonista3, personagem3);
                dialogos[9] = new Dialogo("", protagonista3, personagem3);
                break;
            case 2:
                fundo = new Texture("_cutscene\\fundo1.png");
                quantidadeDialogos = 8;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", protagonista1, personagem1);
                dialogos[1] = new Dialogo("Personagem: nivel 2 blah blah balh", protagonista1, personagem2);
                dialogos[2] = new Dialogo("Protagonista: 1 blah blah blah", protagonista2, personagem3);
                dialogos[3] = new Dialogo("Personagem: 2 blah blah blah", protagonista1, personagem2);
                dialogos[4] = new Dialogo("Protagonista: 3 blah blah blah", protagonista2, personagem1);
                dialogos[5] = new Dialogo("Personagem: 4 blah blah blah", protagonista1, personagem2);
                dialogos[6] = new Dialogo("Protagonista: 5 blah blah balh", protagonista2, personagem1);
                dialogos[7] = new Dialogo("", protagonista2, personagem1);
                break;
            case 3:
                fundo = new Texture("_cutscene\\fundo1.png");
                quantidadeDialogos = 12;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", protagonista1, personagem1);
                dialogos[1] = new Dialogo("Personagem: nivel 3 blah blah balh", protagonista1, personagem2);
                dialogos[2] = new Dialogo("Protagonista: 1 blah blah blah", protagonista2, personagem1);
                dialogos[3] = new Dialogo("Personagem: 2 blah blah blah", protagonista1, personagem2);
                dialogos[4] = new Dialogo("Protagonista: 3 >:(", protagonista3, personagem1);
                dialogos[5] = new Dialogo("Personagem: 4 blah blah blah", protagonista1, personagem2);
                dialogos[6] = new Dialogo("Protagonista: 5 blah blah balh", protagonista2, personagem1);
                dialogos[7] = new Dialogo("Personagem: 6 blah blah balh", protagonista1, personagem2);
                dialogos[8] = new Dialogo("Protagonista: 7 blah blah balh", protagonista2, personagem1);
                dialogos[9] = new Dialogo("Personagem: 8 blah blah balh", protagonista1, personagem2);
                dialogos[10] = new Dialogo("Protagonista: 9 blah blah balh", protagonista2, personagem1);
                dialogos[11] = new Dialogo("", protagonista2, personagem1);
                break;
            case 4:
                fundo = new Texture("_cutscene\\fundo1.png");
                quantidadeDialogos = 6;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", protagonista1, vazio);
                dialogos[1] = new Dialogo("Protagonista: nivel 4 blah blah balh", protagonista1, vazio);
                dialogos[2] = new Dialogo("Protagonista: 1 blah blah blah", protagonista2, vazio);
                dialogos[3] = new Dialogo("Protagonista: 2 blah blah blah", protagonista3, vazio);
                dialogos[4] = new Dialogo("Protagonista: 3 blah blah blah", protagonista2, vazio);
                dialogos[5] = new Dialogo("", protagonista2, vazio);
                break;
            case 5:
                fundo = new Texture("_cutscene\\fundo2.png");
                quantidadeDialogos = 10;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", protagonista1, personagem1);
                dialogos[1] = new Dialogo("Personagem: nivel 5 blah blah balh", protagonista1, personagem2);
                dialogos[2] = new Dialogo("Protagonista: 1 blah blah blah", protagonista2, personagem1);
                dialogos[3] = new Dialogo("Personagem: 2 blah blah blah", protagonista1, personagem2);
                dialogos[4] = new Dialogo("Protagonista: 3 blah blah blah", protagonista2, personagem1);
                dialogos[5] = new Dialogo("Personagem: 4 blah blah blah", protagonista1, personagem2);
                dialogos[6] = new Dialogo("Protagonista: 5 blah blah balh", protagonista2, personagem1);
                dialogos[7] = new Dialogo("Personagem: 6 blah blah balh", protagonista1, personagem2);
                dialogos[8] = new Dialogo("Protagonista: >:(", protagonista3, personagem3);
                dialogos[9] = new Dialogo("", protagonista3, personagem3);
                break;
            case 6:
                fundo = new Texture("_cutscene\\fundo2.png");
                quantidadeDialogos = 10;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", protagonista1, personagem1);
                dialogos[1] = new Dialogo("Personagem: nivel 6 blah blah balh", protagonista1, personagem2);
                dialogos[2] = new Dialogo("Protagonista: 1 blah blah blah", protagonista2, personagem1);
                dialogos[3] = new Dialogo("Personagem: 2 blah blah blah", protagonista1, personagem2);
                dialogos[4] = new Dialogo("Protagonista: 3 blah blah blah", protagonista2, personagem1);
                dialogos[5] = new Dialogo("Personagem: 4 blah blah blah", protagonista1, personagem2);
                dialogos[6] = new Dialogo("Protagonista: 5 blah blah balh", protagonista2, personagem1);
                dialogos[7] = new Dialogo("Personagem: 6 blah blah balh", protagonista1, personagem2);
                dialogos[8] = new Dialogo("Protagonista: >:(", protagonista3, personagem3);
                dialogos[9] = new Dialogo("", protagonista3, personagem3);
                break;
            default:
                fundo = new Texture("_cutscene\\fundo2.png");
                quantidadeDialogos = 2;
                dialogos = new Dialogo[quantidadeDialogos];
                dialogos[0] = new Dialogo("", protagonista1, personagem1);
                dialogos[1] = new Dialogo("", protagonista1, personagem1);
                break;
        }
        temporizadorAnimacao = 1;
        indiceDialogo = 0;
        alfa = 1;
    }

    @Override
    public void resize(int width, int height)
    {
        viewport.update(width, height);
    }

    @Override
    public void dispose()
    {
        batch.dispose();
        font.dispose();
    }

    // Loop do jogo acontece na função render() todo frame.
    @Override
    public void render(float delta)
    {
        // Atualizar a lógica do jogo.
        Atualizar(delta);
        // Iniciar SpriteBatch batch e desenhar os sprites.
        Desenhar();
    }

    // Lógica do jogo
    private void Atualizar(float delta)
    {
        if (indiceDialogo == 0)
        {
            temporizadorAnimacao = temporizadorAnimacao - delta;
            
            if (temporizadorAnimacao < 0)
            {
                if (alfa > 0)
                {
                    alfa = alfa - delta;
                }
                else
                {
                    alfa = 0;
                    temporizadorAnimacao = 2;
                    indiceDialogo++;
                }
            }
        }
        else if (indiceDialogo == quantidadeDialogos - 1)
        {
            alfa = alfa + delta;
                
            if (alfa > 1)
            {
                temporizadorAnimacao = temporizadorAnimacao - delta;
            
                if (temporizadorAnimacao < 0)
                {
                    if (nivel < 6)
                    {
                        jogo.setScreen(new TelaJogo(jogo, nivel));
                    }
                    else
                    {
                        jogo.setScreen(new TelaMenu(jogo));
                    }
                }
            }
        }
        else
        {
            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE) || Gdx.input.isKeyJustPressed(Input.Keys.ENTER))
            {
                beep.play(1);
                indiceDialogo++;
            }
        }   
    }

    private void Desenhar()
    {
        // Preparar novo frame
        jogo.LimparTela();

        // Começar desenho, todos os batch.Draw() e font.Draw() acontecem depois do .begin() e antes do .end();
        batch.begin();
        batch.draw(fundo, 0, 0);
        batch.draw(barraTexto, 0, 0);
        dialogos[indiceDialogo].Desenhar(batch, font);
        batch.setColor(1, 1, 1, alfa);
        batch.draw(cortina, 0, 0);
        batch.setColor(1, 1, 1, 1);
        batch.end();

        // Atualizar as bordas rolantes
        jogo.AtualizarBordas();
    }

    @Override
    public void show()
    {

    }

    @Override
    public void hide()
    {

    }

    @Override
    public void pause()
    {

    }

    @Override
    public void resume()
    {

    }
}
