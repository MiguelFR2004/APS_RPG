package io.github.projeto_aps;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class JanelaUI 
{
    // Enumerador para controlar o estado da janela. (Máquina de estados finita)
	// Cada estado chama uma função que controla o comportamento dos controles do jogo.
    // INICIO: Mostra as ações possíveis (Habilidades e terminar rodada), e os stats do personagem (vida, energia)
    // HABILIDADES: Mostra as habilidades disponíveis para uso.
    // ALVOS: Deixa o jogador escolher qual inimigo vai ser atacado.
    // MENSAGEM: Mostra texto na tela enquanto o jogador não está em controle.
    
    public enum EstadoDaJanela
    {
        INICIO,
        HABILIDADES,
        MENSAGEM;
    }
    
    // Variáveis de desenho
    final private Texture spriteJanela;
    final private Sound beep;
    final private Sound erro;

    // iconeSelecionado, o ícone que gira no item selecionado
    final private float temporizadorConstante;
    private char iconeSelecionado;
    private float temporizadorSelecionado;
    private final char iconeNaoSelecionado;

    // Texto usado para desenho
    final private String textoHabilidades;
    final private String textoTerminar;
    private String textoMensagem;

    // Variável de controle do estado da janela
    private EstadoDaJanela estadoDaJanela;

    // Variável usado para a seleção dos items na janela.
    private int indiceSelecao;

    // Métodos da classe JanelaUI:
    //
    // public JanelaUI()
    // public void Atualizar(Protagonista protagonista, Inimigo inimigo)
    // public void Desenhar(SpriteBatch batch, BitmapFont font, Protagonista protagonista)
    // public void SetEstadoDaJanela(EstadoDaJanela estadoAtual)
    // public void MostrarMensagem(String texto)
    // private void AtualizarInicio(Protagonista protagonista)
    // private void AtualizarHabilidades(Protagonista protagonista, Inimigo inimigo)
    // private void AtualizarMensagem(Protagonista protagonista)
    // private void DesenharInicio(SpriteBatch batch, BitmapFont font, Protagonista protagonista)
    // private void DesenharHabilidades(SpriteBatch batch, BitmapFont font, Protagonista protagonista)
    // private void DesenharMensagem(SpriteBatch batch, BitmapFont font)
    // private void TemporizadorSelecionado()

    // Métodos Públicos
    public JanelaUI(Sound beep)
    {
        spriteJanela = new Texture("menu.png");

        estadoDaJanela = EstadoDaJanela.MENSAGEM;
        indiceSelecao = 0;
        // Habilidades     = indiceSeleçao de 0
        // Terminar Rodada = indiceSelecao de 1
        this.beep = beep;
        erro = Gdx.audio.newSound(Gdx.files.internal("audio\\erro.wav"));

        iconeSelecionado = '-';
        iconeNaoSelecionado = '>';
        temporizadorConstante = 0.1f;
        temporizadorSelecionado = temporizadorConstante;

        textoMensagem = "";
        textoHabilidades = " Habilidades";
        textoTerminar = " Terminar Rodada";
    }

    // Atualizar estado da janela.
    public void Atualizar(Protagonista protagonista, Inimigo inimigo)
    {
        TemporizadorSelecionado();
        
        switch (estadoDaJanela)
        {
            case INICIO:
                AtualizarInicio(protagonista);
                break;
            case HABILIDADES:
                AtualizarHabilidades(protagonista, inimigo);
                break;
            case MENSAGEM:
                AtualizarMensagem(protagonista);
                break;
        }
    }

    // Desenhar estado da janela
    public void Desenhar(SpriteBatch batch, BitmapFont font, Protagonista protagonista)
    {
        batch.draw(spriteJanela, 0, 0);

        switch (estadoDaJanela)
        {
            case INICIO:
                DesenharInicio(batch, font, protagonista);
                break;
            case HABILIDADES:
                DesenharHabilidades(batch, font, protagonista);
                break;
            case MENSAGEM:
                DesenharMensagem(batch, font);
                break;
        }
    }

    // Permite mudar o estado da janela fora da clsse JanelaUI.
    // Deve escrever em uma string com tudo maísculo.
    public void SetEstadoDaJanela(EstadoDaJanela estadoAtual)
    {
        switch (estadoAtual)
        {
            case INICIO:
                indiceSelecao = 0;
                estadoDaJanela = EstadoDaJanela.INICIO;
                break;
            case HABILIDADES:
                indiceSelecao = 0;
                estadoDaJanela = EstadoDaJanela.HABILIDADES;
                break;
            case MENSAGEM:
                estadoDaJanela = EstadoDaJanela.MENSAGEM;
                break;
        }
    }

    // Método para escrever texto na janela. Usado na lógica do SistemaJogo.
    public void MostrarMensagem(String texto)
    {
        textoMensagem = texto;
    }

    // Métodos Privados
    // Métodos de atualização dos estado
    private void AtualizarInicio(Protagonista protagonista)
    {
        // Atualizar o índice da seleção dependendo do input do jogador.
        // Math.floorMod(valor, limite) faz o valor voltar a zero se superar o limite, e ir ao limite se descer ao negativo,
        // criando um loop. Exemplo: (8 + 1, 8) = 0 / (8 + 5, 8) = 4 / (0 - 1, 8) = 8 / (0 - 4, 8) = 5
        // Isso é usado para criar um loop nos items selecionaveis na janela.
        if (Gdx.input.isKeyJustPressed(Keys.W) || Gdx.input.isKeyJustPressed(Keys.DPAD_UP))
        {
            indiceSelecao = Math.floorMod(indiceSelecao - 1, 2);
        }
        if (Gdx.input.isKeyJustPressed(Keys.A) || Gdx.input.isKeyJustPressed(Keys.DPAD_LEFT))
        {
            indiceSelecao = Math.floorMod(indiceSelecao - 1, 2);
        }
        if (Gdx.input.isKeyJustPressed(Keys.D) || Gdx.input.isKeyJustPressed(Keys.DPAD_RIGHT))
        {
            indiceSelecao = Math.floorMod(indiceSelecao + 1, 2);
        }
        if (Gdx.input.isKeyJustPressed(Keys.S) || Gdx.input.isKeyJustPressed(Keys.DPAD_DOWN))
        {
            indiceSelecao = Math.floorMod(indiceSelecao + 1, 2);
        }
        if (Gdx.input.isKeyJustPressed(Keys.SPACE) || Gdx.input.isKeyJustPressed(Keys.ENTER))
        {
            beep.play(1);
            if (indiceSelecao == 0)
            {
                SetEstadoDaJanela(EstadoDaJanela.HABILIDADES);
            }
            if (indiceSelecao == 1)
            {
                protagonista.possuiRodada = false;
            }
        }
    }

    private void AtualizarHabilidades(Protagonista protagonista, Inimigo inimigo)
    {
        // Atualizar o índice da seleção dependendo do input do jogador.
        // Math.floorMod(valor, limite) faz o valor voltar a zero se superar o limite, e ir ao limite se descer ao negativo,
        // criando um loop. Exemplo: (8 + 1, 8) = 0 / (8 + 5, 8) = 4 / (0 - 1, 8) = 8 / (0 - 4, 8) = 5
        // Isso é usado para criar um loop nos items selecionaveis na janela.
        
        if (Gdx.input.isKeyJustPressed(Keys.W) || Gdx.input.isKeyJustPressed(Keys.DPAD_UP))
        {
            indiceSelecao = Math.floorMod(indiceSelecao - 2, protagonista.habilidades.length);
        }
        if (Gdx.input.isKeyJustPressed(Keys.A) || Gdx.input.isKeyJustPressed(Keys.DPAD_LEFT))
        {
            indiceSelecao = Math.floorMod(indiceSelecao - 1, protagonista.habilidades.length);
        }
        if (Gdx.input.isKeyJustPressed(Keys.D) || Gdx.input.isKeyJustPressed(Keys.DPAD_RIGHT))
        {
            indiceSelecao = Math.floorMod(indiceSelecao + 1, protagonista.habilidades.length);
        }
        if (Gdx.input.isKeyJustPressed(Keys.S) || Gdx.input.isKeyJustPressed(Keys.DPAD_DOWN))
        {
            indiceSelecao = Math.floorMod(indiceSelecao + 2, protagonista.habilidades.length);
        }
        if (Gdx.input.isKeyJustPressed(Keys.SPACE) || Gdx.input.isKeyJustPressed(Keys.ENTER))
        {
            if (!protagonista.habilidades[indiceSelecao].Aplicar(protagonista, inimigo, this))
            {
                System.out.println("Energia não suficiente!"); // DEBUG
                erro.play(1);
            }
        }
        if (Gdx.input.isKeyJustPressed(Keys.Z))
        {
            beep.play(1);
            SetEstadoDaJanela(EstadoDaJanela.INICIO);
        }
    }

    private void AtualizarMensagem(Protagonista protagonista)
    {
        if (!Personagem.animacoesEmProgresso && protagonista.possuiRodada)
		{
			SetEstadoDaJanela(JanelaUI.EstadoDaJanela.INICIO);
		}
    }

    // Métodos de desenho dos estado
    // Desenhar Janela em estado INICIO
    private void DesenharInicio(SpriteBatch batch, BitmapFont font, Protagonista protagonista)
    {
        font.setColor(com.badlogic.gdx.graphics.Color.BLACK);
        font.draw(batch, "VIDA: " + protagonista.vidaAtual + " / " + protagonista.vidaMax, 70, 180);
        font.draw(batch, "ENERGIA: " + protagonista.energia + " (+" + protagonista.energiaPorRodada + ")", 70, 130);
        font.draw(batch, "ATAQUE: " + protagonista.ataque, 390, 180);
        font.draw(batch, "DEFESA: " + protagonista.defesa, 390, 130);

        // Se o ínidce é 0, desenhar "Habilidades" em seleção e "Terminar Rodada" desativado. Vice-Versa se for 1.
        if (indiceSelecao == 0)
        {
            font.setColor(com.badlogic.gdx.graphics.Color.BLACK);
            font.draw(batch, iconeSelecionado + textoHabilidades, 70, 230);
            font.setColor(com.badlogic.gdx.graphics.Color.GRAY);
            font.draw(batch, iconeNaoSelecionado + textoTerminar, 390, 230);
        }
        if (indiceSelecao == 1)
        {
            font.setColor(com.badlogic.gdx.graphics.Color.GRAY);
            font.draw(batch, iconeNaoSelecionado + textoHabilidades, 70, 230);
            font.setColor(com.badlogic.gdx.graphics.Color.BLACK);
            font.draw(batch, iconeSelecionado + textoTerminar, 390, 230);
        }
    }

    // Desenhar estado em HABILIDADES
    private void DesenharHabilidades(SpriteBatch batch, BitmapFont font, Protagonista protagonista)
    {
        font.setColor(com.badlogic.gdx.graphics.Color.BLACK);
        font.draw(batch, "ENERGIA: " + protagonista.energia, 680, 230);
        font.draw(batch, "Z para voltar", 680, 180);
        font.draw(batch, protagonista.habilidades[indiceSelecao].GetDescricao(), 70, 80);

        for (Habilidade habilidade : protagonista.habilidades)
        {
           habilidade.Desenhar(batch, font, indiceSelecao, iconeSelecionado, iconeNaoSelecionado);
        }
    }

    // Desenhar estado em MENSAGEM
    private void DesenharMensagem(SpriteBatch batch, BitmapFont font)
    {
        font.setColor(com.badlogic.gdx.graphics.Color.BLACK);
        font.draw(batch, textoMensagem, 70, 230);
    }

    // Atualizar o temporizadorSelecionado a cada x segundos, onde x é igual a temporizadorConstante.
    private void TemporizadorSelecionado()
    {
        temporizadorSelecionado = temporizadorSelecionado - Gdx.graphics.getDeltaTime();

        if (temporizadorSelecionado < 0)
        {
            switch (iconeSelecionado)
            {
                case '-': 
                    iconeSelecionado = '\\';
                    break;
                case '\\': 
                    iconeSelecionado = '|';
                    break;
                case '|': 
                    iconeSelecionado = '/';
                    break;
                case '/': 
                    iconeSelecionado = '-';
                    break;
            }

            temporizadorSelecionado = temporizadorConstante;
        }
    }
}
